﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Assignment1_5204_KAM.Models;

namespace Assignment1_5204_KAM.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            //a new instance of a Student
            Student kelly = new Student();
            kelly.Name = "Kelly Ann McNamara";
            kelly.Student_Id = "n00589472";
            kelly.Program = "Wed Development";

            //a new instance of a Student
            Student mark = new Student();
            mark.Name = "Mark Quinan";
            mark.Student_Id = "n00000001";
            mark.Program = "Chemistry";

            //a new instance of a Student
            Student john = new Student();
            john.Name = "John Doe";
            john.Student_Id = "n00000002";
            john.Program = "Accounting";
            return View(kelly);
        }
    }
}