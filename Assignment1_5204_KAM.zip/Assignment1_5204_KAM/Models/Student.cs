﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Assignment1_5204_KAM.Models
{
    public class Student
    {
        //properties
        public string Name { get; set; }
        public string Student_Id { get; set; }
        public string Program { get; set; }
    }
}